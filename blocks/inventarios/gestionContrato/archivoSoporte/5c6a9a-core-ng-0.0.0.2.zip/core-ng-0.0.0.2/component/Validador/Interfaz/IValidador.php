<?php
namespace component\Validador\interfaz;

interface IValidador{
    
    function validarDato($dato);
    
}


?>