<?php
namespace component\Notificador;

class Parametrizador{
    
    const INACTIVO = 0;
    const ACTIVO = 1;
    const EDITADO = 2;
    const ELIMINADO = 3;
    
    
    
    
    
}