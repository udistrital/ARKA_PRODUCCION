<?php
namespace component\Notificador\interfaz;

interface INotificador{
    
    function datosNotificacionSistema($notificacion);
    
    
}


?>