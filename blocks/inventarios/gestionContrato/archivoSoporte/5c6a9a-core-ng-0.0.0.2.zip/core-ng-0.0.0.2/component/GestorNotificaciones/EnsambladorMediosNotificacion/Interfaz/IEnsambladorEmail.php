<?php
namespace component\EnsambladorEmail\interfaz;

interface IEnsambladorEmail{
    
    function datosNotificacionEmail($notificacion);
    
}


?>