<?php
$this->idioma["usuario"]="Identificación:";
$this->idioma["clave"]="Clave:";
$this->idioma["usuarioTitulo"]="Número de documento";
$this->idioma["claveTitulo"]="Clave de Acceso";
$this->idioma["botonAceptar"]="Aceptar";
$this->idioma["botonCancelar"]="Cancelar";
$this->idioma["noDefinido"]="No definido";
$this->idioma["botonIngresar"]="Ingresar";

?>