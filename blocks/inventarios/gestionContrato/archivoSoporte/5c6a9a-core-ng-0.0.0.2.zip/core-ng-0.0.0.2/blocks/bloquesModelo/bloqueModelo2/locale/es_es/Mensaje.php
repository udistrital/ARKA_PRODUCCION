<?php
$this->idioma ['nombreCampo'] = 'Valor:';
$this->idioma ['botonAceptar'] = 'Aceptar';
$this->idioma ['botonCancelar'] = 'Cancelar';
$this->idioma ['noDefinido'] = 'Etiqueta No definida';
?>
