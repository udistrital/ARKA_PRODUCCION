<?php
$this->idioma["parametroEjemplo"]="Cadena";

?>
