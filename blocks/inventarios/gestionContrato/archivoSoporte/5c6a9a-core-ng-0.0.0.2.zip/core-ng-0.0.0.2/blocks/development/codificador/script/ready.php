<?php 

$_REQUEST['tiempo']=time();


?>