<?php

$atributos ['mensaje'] = 'SARA - Módulo de Asistente de Desarrollo';
$atributos ['tamanno'] = 'Enorme';
$atributos ['linea'] = 'true';
echo $this->miFormulario->campoMensaje ( $atributos );

?>