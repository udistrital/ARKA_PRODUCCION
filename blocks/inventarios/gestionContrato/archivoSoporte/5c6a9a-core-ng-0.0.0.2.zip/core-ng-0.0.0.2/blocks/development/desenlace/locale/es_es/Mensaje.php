<?php
$this->idioma ['formularioDesenlace'] = 'Ingresar la cadena a analizar.';
$this->idioma ['campoCadena'] = 'Cadena: ';
$this->idioma ['campoCadenaTitulo'] = 'Cadena a analizar';
$this->idioma ['botonAceptar'] = 'Aceptar';
$this->idioma ['noDefinido'] = 'Etiqueta No definida';
?>
