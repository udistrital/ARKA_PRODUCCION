<?php
$this->idioma ['nombrePagina'] = 'Nombre de la página:';
$this->idioma ['descripcionPagina'] = 'Descripción:';
$this->idioma ['parametroPagina'] = 'Parámetros predeterminados:';
$this->idioma ['moduloPagina'] = 'Módulo al que pertenece:';
$this->idioma ['nivelPagina'] = 'Nivel de acceso:';
$this->idioma ['botonAceptar'] = 'Aceptar';
$this->idioma ['botonCancelar'] = 'Cancelar';
$this->idioma ['errorDatos'] = '<p>Algunos datos del formulario no se han podido procesar. Por favor corríjalos e intente la operación de nuevo.</p>';
$this->idioma ['errorNombre'] = '<p>Ya existe una página registrada con ese nombre. Por favor cambie el nombre de la página e intente la operación de nuevo.</p>';
$this->idioma ['seleccionar'] = 'Seleccionar acción:';

$this->idioma ['nombreBloque'] = 'Nombre del bloque:';
$this->idioma ['descripcionBloque'] = 'Descripción:';
$this->idioma ['grupoBloque'] = 'Carpeta:';


$this->idioma ['noDefinido'] = 'Etiqueta No definida';
?>
