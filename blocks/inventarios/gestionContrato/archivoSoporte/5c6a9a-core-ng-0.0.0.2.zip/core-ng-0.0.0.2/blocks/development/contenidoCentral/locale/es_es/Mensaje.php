<?php
$this->idioma["usuario"]="Correo:";

$this->idioma["clave"]="Clave:";

$this->idioma["usuarioTitulo"]="Correo Electrónico Registrado";

$this->idioma["claveTitulo"]="Clave de Acceso";

$this->idioma["botonAceptar"]="Aceptar";

$this->idioma["botonCancelar"]="Cancelar";

$this->idioma["noDefinido"]="No definido";
?>