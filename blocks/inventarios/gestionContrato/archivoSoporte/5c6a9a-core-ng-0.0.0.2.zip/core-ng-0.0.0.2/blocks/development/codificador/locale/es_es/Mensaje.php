<?php
$this->idioma ['formularioDesenlace'] = 'Ingresar la cadena a analizar.';
$this->idioma ['campoCadena'] = 'Cadenas (una por línea): ';
$this->idioma ['campoCadenaTitulo'] = 'Cadena a analizar';
$this->idioma ['botonCodificar'] = 'Codificar';
$this->idioma ['botonDecodificar'] = 'Decodificar';
$this->idioma ['noDefinido'] = 'Etiqueta No definida';
?>
