<?php

interface Bloque {
    
    function bloque();

}

?>